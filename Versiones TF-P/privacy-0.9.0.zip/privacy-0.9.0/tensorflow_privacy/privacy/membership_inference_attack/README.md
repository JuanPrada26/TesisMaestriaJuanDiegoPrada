The sources from this folder were moved to
privacy/privacy_tests/membership_inference_attack.
